package com.example.riverdetection;

public class SecondActivity {
}
